package excepciones;

public class EstadioInvalidoException extends Exception {

	public EstadioInvalidoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
