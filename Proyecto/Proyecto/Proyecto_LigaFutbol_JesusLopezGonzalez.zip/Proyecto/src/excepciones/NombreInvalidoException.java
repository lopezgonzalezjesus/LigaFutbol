package excepciones;

public class NombreInvalidoException extends Exception {

	public NombreInvalidoException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
