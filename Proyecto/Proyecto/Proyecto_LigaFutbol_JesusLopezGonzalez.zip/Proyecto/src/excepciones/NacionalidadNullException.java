package excepciones;

public class NacionalidadNullException extends Exception {

	public NacionalidadNullException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
