package excepciones;

public class NumeroMaximoJugadoresException extends Exception {

	public NumeroMaximoJugadoresException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
