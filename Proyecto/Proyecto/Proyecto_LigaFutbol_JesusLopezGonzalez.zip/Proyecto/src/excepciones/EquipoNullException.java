package excepciones;

public class EquipoNullException extends Exception {

	public EquipoNullException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
