package excepciones;

public class PresidenteYaDefinidoException extends Exception {

	public PresidenteYaDefinidoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
