package excepciones;

public class ImagenNoSeleccionadaException extends Exception {

	public ImagenNoSeleccionadaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
