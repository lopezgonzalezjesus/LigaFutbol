package excepciones;

public class DorsalNullException extends Exception {

	public DorsalNullException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
