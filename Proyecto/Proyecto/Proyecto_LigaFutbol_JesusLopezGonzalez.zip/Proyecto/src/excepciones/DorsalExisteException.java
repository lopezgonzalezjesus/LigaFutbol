package excepciones;

public class DorsalExisteException extends Exception {

	public DorsalExisteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
