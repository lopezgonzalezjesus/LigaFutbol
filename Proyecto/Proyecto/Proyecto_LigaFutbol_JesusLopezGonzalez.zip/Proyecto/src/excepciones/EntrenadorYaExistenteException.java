package excepciones;

public class EntrenadorYaExistenteException extends Exception {

	public EntrenadorYaExistenteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
