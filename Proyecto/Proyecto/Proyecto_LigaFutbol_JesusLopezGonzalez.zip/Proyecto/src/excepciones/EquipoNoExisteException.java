package excepciones;

public class EquipoNoExisteException extends Exception {

	public EquipoNoExisteException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
