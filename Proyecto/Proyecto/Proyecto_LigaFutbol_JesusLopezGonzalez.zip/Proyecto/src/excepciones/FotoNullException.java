package excepciones;

public class FotoNullException extends Exception {

	public FotoNullException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
