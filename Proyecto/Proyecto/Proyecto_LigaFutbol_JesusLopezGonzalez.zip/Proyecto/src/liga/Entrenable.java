package liga;

public interface Entrenable {
	
	void entrenar();
	void generarTecnica();

}
