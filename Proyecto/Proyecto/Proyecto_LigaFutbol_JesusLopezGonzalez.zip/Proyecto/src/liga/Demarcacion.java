package liga;

public enum Demarcacion {
	PORTERO,
	DEFENSA,
	CENTROCAMPISTA,
	DELANTERO;
}
