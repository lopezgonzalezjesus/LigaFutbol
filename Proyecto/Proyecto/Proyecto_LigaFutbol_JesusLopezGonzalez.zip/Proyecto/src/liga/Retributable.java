package liga;

public interface Retributable {
	
	void generarSueldo();

}
