package liga;

public enum Cargo {
	PRESIDENTE,
	DIRECTIVO;
}
