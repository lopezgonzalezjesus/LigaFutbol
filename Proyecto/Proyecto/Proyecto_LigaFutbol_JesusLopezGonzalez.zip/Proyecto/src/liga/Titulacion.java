package liga;

public enum Titulacion {

		MASAJISTA,
		ENTRENADOR;
}
